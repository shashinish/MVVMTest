//
//  Error.swift
//  MVVMTest
//
//  Created by Shashi Nishantha on 11/8/19.
//  Copyright © 2019 Shashi Nishantha. All rights reserved.
//

import Foundation

class Error: NSObject {
    var errorCode:Int?
    var errorMessage:String?
    
    init(code : Int,message : String) {
        self.errorCode = code
        self.errorMessage = message
    }
}
